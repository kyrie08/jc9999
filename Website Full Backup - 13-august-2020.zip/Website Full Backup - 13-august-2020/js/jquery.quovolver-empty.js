
/*
 * jQuery Quovolver v1.0 - http://sandbox.sebnitu.com/jquery/quovolver
 *
 * By Sebastian Nitu - Copyright 2009 - All rights reserved
 * 
 */

(function($) {
	$.fn.quovolver = function(speed, delay) {
		
			var	quote = $(this),
				firstQuo = $(this).filter(':first'),
				lastQuo = $(this).filter(':last'),
			$(this).hide();
			$(firstQuo).show();	
		
		// Where the magic happens
		setInterval(function(){
			
			$(quote).filter(':visible').fadeOut(speed);
			
			if($(lastQuo).is(':visible')) {
				var nextElem = $(firstQuo);
			} else {
				var nextElem = $(quote).filter(':visible').next();
			}


			if($(lastQuo).is(':visible')) {
				setTimeout(function() {
					$(firstQuo).fadeIn(speed*2);
				}, speed*2);
				
			} else {
				setTimeout(function() {
					$(nextElem).fadeIn(speed);
				}, speed*2);
			}
			
		}, delay);
	
	};
})(jQuery);
