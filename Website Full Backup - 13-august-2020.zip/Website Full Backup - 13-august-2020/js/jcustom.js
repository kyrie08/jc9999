// custom Javascript for www.joychien.com
// custom codage Javascript pour www.joychien.com

$(document).ready(function() {




	/*  	HELLO PANEL 	*/

	$('#tab-wrapper a').click(function() 
	{
		$this = $(this);
		if ($this.hasClass('chosenlink') === false) {
			$('#tab-wrapper a.chosenlink').removeClass('chosenlink');	/* elim chosenlink state from all links */
			$('.panel').hide();
			$this.addClass('chosenlink').blur();		/* gives chosenlink state to the button that was clicked on */
			var activeId = $this.attr('href');		/* takes URL from tag */
			$(activeId).fadeIn(200);			/* lets ID'd panel fadeIn */
			return false;
			}
		else 
			{return false;}			/* Makes sure the button for current page does nothing. */
	});

	$('#tab-wrapper li:first a').click(); 	/* On page load, chooses the first hello panel */




	/*  	 GALLERY BUTTONS FUNCTIONS, CLOSE PROJECT FUNCTION 	*/

	function chooseProject(n){
		$(n).click(function() { 
			$('.project').hide();
			var $id = '#b' + $(this).attr("id");	// if attr("id") was pro1, add #b
			$($id).fadeIn(800); 				// then $(#bpro1) will fade in NOTE that bpro is weirdly, the panel for project not button as b suggests
			$(document).scrollTo( $('.project-button:last'), 600, {offset:230, easing:'easeOutQuint'} );

			$($id+' .panel-level1').delay(100).fadeIn(200);
			$($id+' .panel-level3').delay(300).fadeIn(400);

			$( ".close-project" ).click(function() {
 				$($id+' .panel-level3').fadeOut(400);
 				$($id).delay(200).fadeOut(400);
 				$(document).delay(300).scrollTo( $('.project-button:first'), 400, {offset:-140} );
			}); // end close project
		}); // end click function
	} // end chooseProject

	chooseProject('.project-button');




	/*  	 GBACK TO TOP FUNCTION 	*/
	function getOffset( el ) {
		var _x = 0;
		var _y = 0;
		while( el && !isNaN( el.offsetLeft ) && !isNaN( el.offsetTop ) ) {
			_x += el.offsetLeft - el.scrollLeft;
			_y += el.offsetTop - el.scrollTop;
			el = el.offsetParent;
			}
		return { top: _y, left: _x };
	}
	

	function scrollCheck() {
			var topAppearHere = getOffset( document.getElementById('row3') ).top; 
			topAppearHere -= 150; /* offset amount */
			var top  = window.pageYOffset || document.documentElement.scrollTop;
					if (top > topAppearHere) {  
						$('#back-to-top').addClass('visible');
				} else {$('#back-to-top').removeClass('visible');}
			}
/*			var topAppearHere = document.getElementById('btt-button-appear-here').pageYOffset;

$('#back-to-top').animate({opacity: 0}, {duration: 0.1});
				} else {$('#back-to-top').fadeTo(0.75, 500);}
*/
	setInterval(function(){
			scrollCheck();
		},400);

	$('#back-to-top').click(function(){
			$(document).scrollTo( $('#row1'), 600, {offset:-40, easing:'easeOutQuint'} );
		});




	/*  	 APPENDING ZOOMGLASSES + ZOOMGLASS MINI 	*/
		
	$('.workbox').append('<div class="zoomglass"></div>');
	$('.grid2 img').before('<div class="zoomglass-mini"></div>');
	$('.grid img').before('<div class="zoomglass-mini"></div>');


}); // end document ready
